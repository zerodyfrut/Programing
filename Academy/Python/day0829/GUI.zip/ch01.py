import tkinter as tk

# 윈도우 생성
window = tk.Tk()
window.title("tkinter 위젯 예제")
window.geometry("400x400")


# 실행
window.mainloop()

